/*This Was Last Updated Tuesday, January 25, 2011 if it is past Tuesday, January 25, 2012 This is outdated*/
/*If You have not made a hello world Program and did lesson 1 c1 OFV and 1 c2 OFV I would reccomend you do so */
/*This Program is basicly going to print the values recived in the ram and print them at the end*/
#include<stdio.h>
int main()
{
      int dateofbirth;  //Right Here im Creating Intger Variables (or any number that is not a fraction
      int age;          //variables store values in the memory
      int address;      //right now the variables are raw meaning they dont have a value yet
      int phone;        //later we will assign values by using some thing called a assignment operator 
      printf("Noahs C Learning Lesson 2 c2 This is Liscenced Under The Creative Commons Attribution 3.0 Unported License More Under Readme.txt");
      printf("Simple form Example"); //printf is standard in the stdio header printf basicly prints what ever is in the string literals or "" 
      printf("Enter Your age:"); //now were asking for the persons age using printf
      scanf("%d", &age); //were now using scanf to ask for input and sending the input to the age variable 
      printf("what is your day of birth");
      scanf("%d", &dateofbirth); //were now using scanf to ask for input and sending the input to the dateofbirth variable 
      printf("whats your age");
      scanf("%d", &age); //were now using scanf to ask for input and sending the input to the age variable 
      printf("whats your adress");
      scanf("%d", &address); //were now using scanf to ask for input and sending the input to the adress variable 
      if(age > 18){
             printf("Hey Oldtimer/n");
             }
             else
             {
                 printf("Hey Youngster/n");
                 }
                 }
                 
       
