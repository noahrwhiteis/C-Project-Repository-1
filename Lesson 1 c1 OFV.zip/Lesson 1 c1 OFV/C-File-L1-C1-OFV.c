//This is licensed under the creative commons Creative Commons Attribution 3.0 Unported License for more go to README.txt
#include<stdio.h> //were including the basic input output header
main() // this starts our statement or (function)
{
    printf("Hello World");//the printf means were goint to print text to the screen
    getchar(); // the getchar will wait for a enter
}
